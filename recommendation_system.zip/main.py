import sys
import argparse
from pathlib import Path
import logging
from utils.logging import setup_logger

# Инициализация логгера ДО всех импортов
logger = setup_logger()

# Остальные импорты
from data.loader import load_data
from data.preprocessor import preprocess_data, filter_features
from features.builder import build_features, build_interaction_matrix
from models.knn import optimize_knn, generate_recommendations
from evaluation.metrics import evaluate_recall
from config import SUBMISSION_FILE, DATA_SAMPLE_RATIO


def main():
    try:
        logger.info("=== Starting recommendation system ===")

        # 1. Загрузка данных
        data = load_data()
        if not data:
            raise ValueError("No data loaded")

        # 2. Предобработка
        preprocessed_data = preprocess_data(data)
        preprocessed_data = filter_features(preprocessed_data)

        # 3. Построение признаков
        feature_data = build_features(preprocessed_data)
        interaction_data = build_interaction_matrix(preprocessed_data, feature_data)

        # ... остальной код ...

    except Exception as e:
        logger.exception("Fatal error in main process")
        sys.exit(1)


if __name__ == '__main__':
    main()